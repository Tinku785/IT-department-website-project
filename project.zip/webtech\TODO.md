# TODO: Run the University IT Department Website

- [x] Start the development server using `npm run dev`
- [x] Open the website in a browser at http://localhost:3000 (manual step)
- [x] Verify the site loads correctly (thorough testing requested but browser tool disabled; manual verification recommended)
